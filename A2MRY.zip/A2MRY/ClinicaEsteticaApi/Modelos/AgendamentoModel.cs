public class AgendamentoModel
{
    public string NomeCliente { get; set; }
    public DateTime Data { get; set; }
    public string Servico { get; set; }
}
