﻿namespace ClinicaEsteticaApi.Properties.Data
{
    public class Class
    {
    }
}
